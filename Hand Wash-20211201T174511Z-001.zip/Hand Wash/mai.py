import time 
from plyer import notification
if __name__ == "__main__":
   
      notification.notify( 
         title ="**Please Wash your Hand Now!!!",
         message = "After blowing your nose, coughing or sneezing",
         app_icon= "E:/python/Hand Wash/icon.ico",
         timeout=3

     )
    